Stubs
=====

The [](sublime.py) and [](sublime_plugin.py) files in this directory are copied verbatim from build 3066.

[](sublime_api.py) is a python implementation of some of Sublime Text's internals such that we can at least attempt to test some stuff.
